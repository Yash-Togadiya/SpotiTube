import React from "react";
import "./Playlistgrid.css";

function Playlistgrid() {
    return (
        <div className="playlistgrid">
            <div className="playlistimg">
                <img
                    src="https://t4.ftcdn.net/jpg/05/65/29/91/240_F_565299140_9QjAaoEpcaHKI4HJdyEdtJJ8f3V6RwlY.jpg"
                    alt="img"
                />
                {/* <img
                    src="https://t3.ftcdn.net/jpg/05/42/88/46/240_F_542884696_2Zz1Rh3YNfVeUyelLPOYGdvxnGA9WMIb.jpg"
                    alt="img"
                /> */}
                <h1>Name</h1>
            </div>
            <div className="playlistgriditems">
                <ul>
                    <li>Song-1</li>
                    <li>Song-2</li>
                    <li>Song-3</li>
                    <li>Song-4</li>
                    <li>Song-5</li>
                    <li>Song-6</li>
                    <li>Song-7</li>
                    <li>Song-8</li>
                    <li>Song-9</li>
                    <li>Song-10</li>
                </ul>
            </div>
        </div>
    );
}

export default Playlistgrid;
